let arregloNumeros: Array<number>;

arregloNumeros = [1,2,3,4];
//arregloNumeros = ["Juan","Karla"];


console.log(arregloNumeros);
console.log(arregloNumeros[0]);